# Ender-2 Pro

The Creality3D Ender-2 Pro was released in December 2021 sporting a 32-bit Creality Silent board labeled as version 4.2.3. This board is a bit mysterious as it is completely absent from Creality's documentation. It differs only slightly from board version 4.2.2 with the Bed Heater pin exchanged with one of the Encoder pins.
